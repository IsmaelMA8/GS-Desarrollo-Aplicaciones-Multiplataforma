/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trabajoenfoque;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class TrabajoEnfoqueNumeros {

    public static void main(String[] args) {

        Scanner sn = new Scanner(System.in);

        //Creamos una variable CONSTANTE que pida 10 números.
        final int NUMEROSMAX = 10;

        //Creamos una lista para pares y otra para impares.
        ArrayList<Integer> listaNumerosPares = new ArrayList<>();
        ArrayList<Integer> listaNumerosImpares = new ArrayList<>();

        //Creamos un bucle que nos repase la lista hasta 10 números.
        for (int i = 1; i <= NUMEROSMAX; i++) {
            System.out.println("Inserte un número:");

            //Pedimos el número por teclado
            int numeroIntroducido = sn.nextInt();

            // Según se introduzcan los números se clasificarán en pares o impares
            if (numeroIntroducido % 2 == 0) {
                listaNumerosPares.add(numeroIntroducido);
                System.out.println("Añadido a Lista de pares: " + numeroIntroducido);
            } else {
                listaNumerosImpares.add(numeroIntroducido);
                System.out.println("Añadido a lista de impares: " + numeroIntroducido);
            }
        }

        // Ordenar y mostramos resultados.
        Collections.sort(listaNumerosPares);
        Collections.sort(listaNumerosImpares);

        System.out.println("Lista de números pares: " + listaNumerosPares + " En total son: " + listaNumerosPares.size());
        System.out.println("Lista de números impares: " + listaNumerosImpares + " En total son: " + listaNumerosImpares.size());

        sn.close();
    }
}
