
import com.mycompany.tedesarrollointerfaces.clases.Alquiler;
import com.mycompany.tedesarrollointerfaces.clases.AlquilerDAO;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

public class TestBusqueda {
    
    
   @Test
    public void testBusquedaPorFechas() {
        // --- 1. ARRANGE (Preparar datos) ---
        // Definimos el rango: Del 1 al 31 de Enero de 2024
       
        LocalDate fechaInicioBusqueda = LocalDate.of(2024, 1, 1);
        LocalDate fechaFinBusqueda = LocalDate.of(2024, 1, 31);

        List<Alquiler> listaSimulada = new ArrayList<>();

        // Alquiler 1: DENTRO del rango (15 de Enero 2024)
        Alquiler alq1 = new Alquiler();
        alq1.setFechaEntrada(LocalDate.of(2024, 1, 15));
        listaSimulada.add(alq1);

        // Alquiler 2: FUERA del rango (Año pasado 2023)
        Alquiler alq2 = new Alquiler();
        alq2.setFechaEntrada(LocalDate.of(2023, 1, 15));
        listaSimulada.add(alq2);

        // Alquiler 3: FUERA del rango (Futuro, Febrero 2024)
        Alquiler alq3 = new Alquiler();
        alq3.setFechaEntrada(LocalDate.of(2024, 2, 15));
        listaSimulada.add(alq3);

        
        int encontrados = 0;
        for (Alquiler a : listaSimulada) {
            LocalDate fecha = a.getFechaEntrada();
            
            // Lógica para LocalDate:
            // "No es anterior al inicio" Y "No es posterior al fin"
            if (!fecha.isBefore(fechaInicioBusqueda) && !fecha.isAfter(fechaFinBusqueda)) {
                encontrados++;
            }
        }

        
        assertEquals("El buscador debería haber encontrado exactamente 1 alquiler", 
                     1, encontrados);
    }
    
    @Test
    public void testBusquedaSinResultados() {
        System.out.println("Ejecutando prueba: Búsqueda sin coincidencias");
        
        
        // Instanciamos el DAO
        AlquilerDAO dao = new AlquilerDAO(); 
        
        // Definimos fechas donde SABEMOS que no hay datos (ej. año 2090)
       
        LocalDate fechaInicio = LocalDate.of(2090, 1, 1);
        LocalDate fechaFin = LocalDate.of(2090, 1, 31);

        
        ArrayList<Alquiler> resultado = dao.listaAlquiler(fechaInicio, fechaFin);

        
        
        // Verificamos que NO devuelve null (regla de oro para evitar NullPointer)
        assertNotNull("El método no debe devolver null, debe devolver una lista vacía", resultado);
        
        // Verificamos que el tamaño es 0 (la lista está vacía)
        assertTrue("La lista debería estar vacía porque no hay alquileres en 2090", resultado.isEmpty());
        
       
    }
}
    

