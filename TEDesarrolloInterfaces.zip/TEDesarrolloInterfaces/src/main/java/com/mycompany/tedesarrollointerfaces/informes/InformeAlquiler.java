package com.mycompany.tedesarrollointerfaces.informes;

import com.mycompany.tedesarrollointerfaces.clases.Alquiler;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

public class InformeAlquiler {

    /**
     * Método para generar y mostrar el informe de alquileres.
     *
     * @param listaAlquileres La lista de objetos Alquiler recuperada de la BD.
     */
    public void mostrarInforme() {
        try {

           
            var reporteStream = getClass().getResourceAsStream("/InformeAlquiler.jrxml");

            if (reporteStream == null) {
                System.out.println("No encuentro el archivo. Revisa que esté en src/main/resources");
                return;
            }

           
            JasperReport reporte = JasperCompileManager.compileReport(reporteStream);

            String url = "jdbc:mysql://localhost:3306/smartocupationdatabase?serverTimezone=UTC";
            Connection conexion = DriverManager.getConnection(url, "root", "");

            
            Map<String, Object> parametros = new HashMap<>();

            
            JasperPrint print = JasperFillManager.fillReport(reporte, parametros, conexion);

         
            JasperViewer.viewReport(print, false);

        } catch (Exception e) {
            e.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
}
