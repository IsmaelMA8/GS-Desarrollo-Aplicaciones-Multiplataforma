package com.mycompany.tedesarrollointerfaces.clases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ClienteDAO {
    
  

    public boolean nuevoCliente(Cliente cli) {
        
        boolean registrado = false;
        
        String sql = "INSERT INTO clientes (dni, nombre, apellido, telefono_contacto, datos_facturacion) VALUES (?, ?, ?,?,?)";
        
        try {
            
            ConexionBD conexion = new ConexionBD();
            Connection con = conexion.getConexionBD();
            
            PreparedStatement ps = con.prepareStatement(sql);
            
            ps.setString(1, cli.getDni());
            ps.setString(2, cli.getNombre());
            ps.setString(3, cli.getApellido());
            ps.setString(4, cli.getTelefono());
            ps.setString(5, cli.getDatosFacturacion());
           
            if (ps.executeUpdate() > 0) {
                
                registrado = true;
                
            }
            
            con.close();
            
        } catch (SQLException e) {
            System.out.println("Error al insertar cliente:" + e.getMessage());
        }
        
        return registrado;
    }
}

