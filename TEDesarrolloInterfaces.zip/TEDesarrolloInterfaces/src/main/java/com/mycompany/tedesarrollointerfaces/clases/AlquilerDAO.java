package com.mycompany.tedesarrollointerfaces.clases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.time.LocalDate;

public class AlquilerDAO {

    public ArrayList<Alquiler> listaAlquiler(LocalDate fechaInicio, LocalDate fechaFin) {

        ArrayList<Alquiler> lista = new ArrayList();

        ConexionBD conexion = new ConexionBD();
        Connection con = conexion.getConexionBD();

        try {
            String sql = "SELECT * FROM alquileres WHERE fecha_entrada BETWEEN ? AND ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setDate(1, java.sql.Date.valueOf(fechaInicio));
            ps.setDate(2, java.sql.Date.valueOf(fechaFin));
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Alquiler alq = new Alquiler();

                alq.setIdCliente(rs.getInt("fk_id_cliente"));
                alq.setIdVivienda(rs.getInt("fk_id_vivienda"));

                alq.setNumExpediente(rs.getInt("num_expediente"));
                alq.setTiempoEstimadoMeses(rs.getInt("tiempo estimado_meses"));

                String textoEstado = rs.getString("estado_Pago");
                alq.setEstadoPago(Alquiler.EstadoPago.valueOf(textoEstado));

                alq.setFechaEntrada(rs.getDate("fecha_entrada").toLocalDate());

                lista.add(alq);
            }

        } catch (SQLException e) {
            System.out.println("Error al devolver lista.");
        }

        return lista;
    }

}
