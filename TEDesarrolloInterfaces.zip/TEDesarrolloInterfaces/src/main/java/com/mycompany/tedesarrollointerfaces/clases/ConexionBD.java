/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tedesarrollointerfaces.clases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private static final String URL = "jdbc:mysql://localhost:3306/smartocupationdatabase";
    private static final String USER = "root";  // Usuario por defecto en XAMPP/WAMP
    private static final String PASS = "";      // Contraseña por defecto suele ser vacía

    Connection conec;

    public Connection getConexionBD() {

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            conec = DriverManager.getConnection(URL, USER, PASS);
            
            System.out.println("¡Conexión efectuada correctamente!");
            
        } catch (Exception e) {
            System.out.println("Error: No se ha podido establecer la conexion." + e.toString());
        }
        
        return conec;

    }
  
}
