
package com.mycompany.tedesarrollointerfaces.clases;


public class Vivienda {
    
    private int idVivienda;
    private String codigoReferencia;
    private String ubicacion;
    private int metros;
    private int numHabitaciones;
    private int numBanos;
    private double precioMensual; // En BBDD es DECIMAL, en Java usamos double

    public Vivienda() {
        
    }

    public Vivienda(int idVivienda, String codigoReferencia, String ubicacion, int metros, int numHabitaciones, int numBanos, double precioMensual) {
        this.idVivienda = idVivienda;
        this.codigoReferencia = codigoReferencia;
        this.ubicacion = ubicacion;
        this.metros = metros;
        this.numHabitaciones = numHabitaciones;
        this.numBanos = numBanos;
        this.precioMensual = precioMensual;
    }
    
    //Aplicamos la misma logica del constructor con ID y sin ID, como hemos comentado en "Cliente"
    public Vivienda(String codigoReferencia, String ubicacion, int metros, int numHabitaciones, int numBanos, double precioMensual) {
        this.codigoReferencia = codigoReferencia;
        this.ubicacion = ubicacion;
        this.metros = metros;
        this.numHabitaciones = numHabitaciones;
        this.numBanos = numBanos;
        this.precioMensual = precioMensual;
    }

    public int getIdVivienda() {
        return idVivienda;
    }

    public void setIdVivienda(int idVivienda) {
        this.idVivienda = idVivienda;
    }

    public String getCodigoReferencia() {
        return codigoReferencia;
    }

    public void setCodigoReferencia(String codigoReferencia) {
        this.codigoReferencia = codigoReferencia;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public int getMetros() {
        return metros;
    }

    public void setMetros(int metros) {
        this.metros = metros;
    }

    public int getNumHabitaciones() {
        return numHabitaciones;
    }

    public void setNumHabitaciones(int numHabitaciones) {
        this.numHabitaciones = numHabitaciones;
    }

    public int getNumBanos() {
        return numBanos;
    }

    public void setNumBanos(int numBanos) {
        this.numBanos = numBanos;
    }

    public double getPrecioMensual() {
        return precioMensual;
    }

    public void setPrecioMensual(double precioMensual) {
        this.precioMensual = precioMensual;
    }

    @Override
    public String toString() {
        return "Viviendas{" + "idVivienda=" + idVivienda + ", codigoReferencia=" + codigoReferencia + ", ubicacion=" + ubicacion + ", metros=" + metros + ", numHabitaciones=" + numHabitaciones + ", numBanos=" + numBanos + ", precioMensual=" + precioMensual + '}';
    }
    
    
}   
