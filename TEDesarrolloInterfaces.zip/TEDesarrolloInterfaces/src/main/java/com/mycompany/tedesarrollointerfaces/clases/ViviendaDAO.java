
package com.mycompany.tedesarrollointerfaces.clases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ViviendaDAO {
    
    public boolean nuevaVivienda (Vivienda viv) {
        
        boolean registradaV = false;
        
        String sql = "INSERT INTO viviendas (codigo_referencia, ubicacion, metros, num_habitaciones, num_banos, precio_mensual) VALUES (?, ?, ?, ?, ?, ?)";
       
        try {
            
            ConexionBD conexion = new ConexionBD();
            Connection con = conexion.getConexionBD();
            
            PreparedStatement ps = con.prepareStatement(sql);
            
            ps.setString(1, viv.getCodigoReferencia());
            ps.setString(2, viv.getUbicacion());
            ps.setInt(3, viv.getMetros());
            ps.setInt(4, viv.getNumHabitaciones());
            ps.setInt(5, viv.getNumBanos());
            ps.setDouble(6, viv.getPrecioMensual());
            
           
           
            if (ps.executeUpdate() > 0) {
                
                registradaV = true;
                
            }
            
            con.close();
            
        } catch (SQLException e) {
            System.out.println("Error al insertar vivienda:" + e.getMessage());
        }
        
        return registradaV;
    }
    
    public Vivienda obtenerPorId(int idBuscado) {
    Vivienda viv = null;
    
    //Usamos SELECT, en lugar de INSERT, para obtener los precios de las vivienda que los refleje en la BBDD.
    String sql = "SELECT * FROM viviendas WHERE id_vivienda = ?"; 
    
    try {
        
        ConexionBD conexion = new ConexionBD();
        Connection con = conexion.getConexionBD();
        
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, idBuscado);
        
        ResultSet rs = ps.executeQuery();
        
        if (rs.next()) {
           
            viv = new Vivienda();
            viv.setIdVivienda(rs.getInt("id_vivienda"));
            viv.setPrecioMensual(rs.getDouble("precio_mensual")); 
        }
        
        
        con.close();
        
    } catch (SQLException e) {
        System.out.println("Error al buscar vivienda: " + e.getMessage());
    }
    
    return viv;
}
}
    

