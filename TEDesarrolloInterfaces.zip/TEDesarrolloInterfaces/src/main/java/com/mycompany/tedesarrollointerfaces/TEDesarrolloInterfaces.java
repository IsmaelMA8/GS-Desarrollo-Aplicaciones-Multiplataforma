
package com.mycompany.tedesarrollointerfaces;

import com.mycompany.tedesarrollointerfaces.clases.Cliente;
import com.mycompany.tedesarrollointerfaces.clases.ClienteDAO;
import com.mycompany.tedesarrollointerfaces.clases.Vivienda;
import com.mycompany.tedesarrollointerfaces.clases.ViviendaDAO;
import com.mycompany.tedesarrollointerfaces.gui.VentanaPrincipal;
import javax.swing.SwingUtilities;


public class TEDesarrolloInterfaces {

    public static void main(String[] args) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
               new VentanaPrincipal().setVisible(true);
            }
        });
        
    }
}
