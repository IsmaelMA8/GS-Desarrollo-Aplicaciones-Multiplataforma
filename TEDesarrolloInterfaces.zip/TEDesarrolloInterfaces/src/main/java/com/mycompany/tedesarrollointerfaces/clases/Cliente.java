
 
package com.mycompany.tedesarrollointerfaces.clases;


public class Cliente {
    
    private int idCliente;
    private String dni;
    private String nombre;
    private String apellido;
    private String telefono; //String para evitar que no ignore si empieza por 0 el numero
    private String datosFacturacion;

    public Cliente() {
        
        
        
    }

    public Cliente(int idCliente, String dni, String nombre, String apellido, String telefono, String datosFacturacion) {
        this.idCliente = idCliente;
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.datosFacturacion = datosFacturacion;
    }
    
    //Creamos este contructor sin el atributo ID, de esta manera creamos un cliente nuevo en la BD, al contrario de el constructor con ID, que sería como para consultar usuarios ya existentess.
    public Cliente(String dni, String nombre, String apellido, String telefono_contacto, String datosFacturacion) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono_contacto;
        this.datosFacturacion = datosFacturacion;
    }
    
    

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDatosFacturacion() {
        return datosFacturacion;
    }

    public void setDatosFacturacion(String datosFacturacion) {
        this.datosFacturacion = datosFacturacion;
    }

    @Override
    public String toString() {
        return "Cliente{" + "idCliente=" + idCliente + ", dni=" + dni + ", nombre=" + nombre + ", apellido=" + apellido + ", telefono=" + telefono + ", datosFacturacion=" + datosFacturacion + '}';
    }
    
    
    
}
