
package com.mycompany.tedesarrollointerfaces.clases;

import java.time.LocalDate;



public class Alquiler {
    
    public enum EstadoPago {
        PAGADO, PENDIENTE, CANCELADO
    }
    
    private int numExpediente; // Este es el ID del alquiler
    private LocalDate fechaEntrada;
    private int tiempoEstimadoMeses;
    private EstadoPago estadoPago;
    
    // Relaciones (Foreign Keys)
    // Guardamos los IDs para relacionarlo fácilmente al guardar en BBDD
    private int idCliente; 
    private int idVivienda;

    public Alquiler() {
    }

    public Alquiler(int numExpediente, LocalDate fechaEntrada, int tiempoEstimadoMeses, EstadoPago  estadoPago, int idCliente, int idVivienda) {
        this.numExpediente = numExpediente;
        this.fechaEntrada = fechaEntrada;
        this.tiempoEstimadoMeses = tiempoEstimadoMeses;
        this.estadoPago = estadoPago;
        this.idCliente = idCliente;
        this.idVivienda = idVivienda;
    }

    public Alquiler(LocalDate fechaEntrada, int tiempoEstimadoMeses, EstadoPago estadoPago, int idCliente, int idVivienda) {
        this.fechaEntrada = fechaEntrada;
        this.tiempoEstimadoMeses = tiempoEstimadoMeses;
        this.estadoPago = estadoPago;
        this.idCliente = idCliente;
        this.idVivienda = idVivienda;
    }

    public int getNumExpediente() {
        return numExpediente;
    }

    public void setNumExpediente(int numExpediente) {
        this.numExpediente = numExpediente;
    }

    public LocalDate getFechaEntrada() {
        return fechaEntrada;
    }

    public void setFechaEntrada(LocalDate fechaEntrada) {
        this.fechaEntrada = fechaEntrada;
    }

    public int getTiempoEstimadoMeses() {
        return tiempoEstimadoMeses;
    }

    public void setTiempoEstimadoMeses(int tiempoEstimadoMeses) {
        this.tiempoEstimadoMeses = tiempoEstimadoMeses;
    }

    public EstadoPago getEstadoPago() {
        return estadoPago;
    }

    public void setEstadoPago(EstadoPago estadoPago) {
        this.estadoPago = estadoPago;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getIdVivienda() {
        return idVivienda;
    }

    public void setIdVivienda(int idVivienda) {
        this.idVivienda = idVivienda;
    }

    @Override
    public String toString() {
        return "Alquiler{" + "numExpediente=" + numExpediente + ", fechaEntrada=" + fechaEntrada + ", tiempoEstimadoMeses=" + tiempoEstimadoMeses + ", estadoPago=" + estadoPago + ", idCliente=" + idCliente + ", idVivienda=" + idVivienda + '}';
    }

    

    

    
    
}
