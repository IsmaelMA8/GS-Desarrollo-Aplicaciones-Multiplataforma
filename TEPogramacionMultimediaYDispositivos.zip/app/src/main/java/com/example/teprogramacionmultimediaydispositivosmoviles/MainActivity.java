package com.example.teprogramacionmultimediaydispositivosmoviles;

import static com.example.teprogramacionmultimediaydispositivosmoviles.Preferences.KEY_ULTIMA_CONVERSION;
import static com.example.teprogramacionmultimediaydispositivosmoviles.Preferences.PREFS_NAME;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Toast;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText cantidadConvertir;
    private TextView resultado;

    private RadioGroup conversiones;

    private RadioButton metroskm, kmmetros,gradoskg, kggramos, celsfaren, farencels;

    private Button calcular, borrar, guardar, mostrar;




    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        cantidadConvertir = findViewById(R.id.cantidadConvertir);
        resultado = findViewById(R.id.resultado);
        conversiones = findViewById(R.id.conversiones);

        metroskm = findViewById(R.id.metroskm);
        kmmetros = findViewById(R.id.kmmetros);
        gradoskg = findViewById(R.id.gramoskg);
        kggramos = findViewById(R.id.kggramos);
        celsfaren = findViewById(R.id.celsfaren);
        farencels = findViewById(R.id.farencels);


        calcular = findViewById(R.id.calcular);
        borrar = findViewById(R.id.borrar);
        guardar = findViewById(R.id.guardar);
        mostrar = findViewById(R.id.mostrar);




        //Lógica de los botones:

        //CONVERSION

        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cantidadConvertir.getText().toString().isEmpty()) {
                    cantidadConvertir.setError("Introduzca un valor en primer lugar: ");
                    return;
                }

                realizarConversion();

            }
        });

        //BORRADO

        borrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cantidadConvertir.setText("");
                resultado.setText("");
            }
        });

        //GUARDADO


        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarConversion();

            }

        });

        //MOSTRAR

        mostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cargarUltimaConversion();
            }
        });


    }

    //Código de las operaciones de conversion:
    private void realizarConversion() {
        double valor = Double.parseDouble(cantidadConvertir.getText().toString());
        double resultado = 0;
        String unidad = "";

        if (metroskm.isChecked()) {
            resultado = valor / 1000;
            unidad = "km";
        } else if (kmmetros.isChecked()) {
            resultado = valor * 1000;
            unidad = "m";

        } else if (gradoskg.isChecked()) {
            resultado = valor / 1000;
            unidad = "kg";
        } else if (kggramos.isChecked()) {
            resultado = valor * 1000;
            unidad = "g";

        } else if (celsfaren.isChecked()) {
            resultado = (valor * 9 / 5) + 32;
            unidad = "F";
        }else if (farencels.isChecked()) {
            resultado = (valor - 32) * 5 / 9;
            unidad = "C";

        } else {
            Toast.makeText(this, "Seleccione una opción", Toast.LENGTH_SHORT).show();
            return;
        }

        this.resultado.setText(String.valueOf(resultado) + " " + unidad);


    }

    private void guardarConversion() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_ULTIMA_CONVERSION, resultado.getText().toString());
        editor.apply();

        Toast.makeText(this, "Conversion guardada", Toast.LENGTH_SHORT).show();

    }

    private void cargarUltimaConversion() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String ultimaConversion = sharedPreferences.getString(KEY_ULTIMA_CONVERSION, "");
        resultado.setText(ultimaConversion);
        Toast.makeText(this, "Última conversion mostrada", Toast.LENGTH_SHORT).show();
    }
}
