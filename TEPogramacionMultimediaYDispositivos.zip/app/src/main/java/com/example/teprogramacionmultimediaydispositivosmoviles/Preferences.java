package com.example.teprogramacionmultimediaydispositivosmoviles;

public class Preferences {

    public static final String PREFS_NAME = "MisDatosApp";
    public static final String KEY_ULTIMA_CONVERSION = "ultima_conversion";
}
