/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.teprogramacionserviciosyprocesos;

import com.mycompany.teprogramacionserviciosyprocesos.clases.Cliente;
import java.util.concurrent.Semaphore;

/**
 *
 * @author ISMAM
 */
public class TEProgramacionServiciosYProcesos {

    public static void main(String[] args) {
        
        
        // Iniciamos el semáforo e indicamos los cuatro vehículos a probar
        Semaphore semaforo = new Semaphore (4);
        
        System.out.println("------SIMULACION INICIADA-----");
        
        // En este blucle recorremos los nueve clientes. Iniciaremos los nueve clientes, en relacion al semaforo y las cuatro posiciones
        
        for (int i = 1; i <= 9; i++) {
            
            Cliente cli = new Cliente (semaforo, i);
            
            cli.start();
        }
        
        
    }
}
