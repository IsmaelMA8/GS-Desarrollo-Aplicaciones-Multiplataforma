/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.teprogramacionserviciosyprocesos.clases;

import java.util.concurrent.Semaphore;


public class Cliente extends Thread{
    
    private Semaphore semaforo;
    private int idCliente;

    public Cliente(Semaphore Semaforo, int IdCliente) {
        this.semaforo = Semaforo;
        this.idCliente = IdCliente;
    }
    
    public void run () {
        
        try {
            // El cliente espera aquí si no le toca
            semaforo.acquire();
            
            // Generamos número entre 1 a 4 (aleatorio)
            int numVehiculo = (int) (Math.random() * 4) + 1;
            
            System.out.println("Cliente " + idCliente + "... probando vehiculo... " + numVehiculo);
            
            // Indicamos que se espere 1 segundo
            Thread.sleep(1000);
            
            System.out.println("Cliente " + idCliente + "... termino de probar el vehiculo... ");
            
            // Pasar turno a otro cliente
            
            semaforo.release();
            
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        
        
        
    }
    
    
}
