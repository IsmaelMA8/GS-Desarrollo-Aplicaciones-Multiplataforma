package com.mycompany.teaccesodatos;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TEAccesoDatos {

    public static void main(String[] args) {

        //Manejaremos posibles errores de lectura de archivo con el try-catch
        try {

            SAXParserFactory factory = SAXParserFactory.newInstance();

            SAXParser parser = factory.newSAXParser();

            ManejadorContratos manejador = new ManejadorContratos();

            File archivo = new File("contratos.xml");

            if (archivo.exists()) {
                System.out.println("--- INICIO DE PROCESO ---");

                parser.parse(archivo, manejador);

                System.out.println("--- PROCESO FINALIZADO ---");

                ConexionBD gestorConexion = new ConexionBD();
                Connection conec = gestorConexion.conectar();

                if (conec != null) {
                    // Preparamos la consulta
                    String sql = "INSERT INTO contratos (nif, adjudicatario, objeto_generico, objeto, fecha_adjudicacion, importe, proveedores_consultados) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement pstmt = conec.prepareStatement(sql);

                    for (Contrato c : manejador.getListaContratos()) {

                        // Mostramos por consola (tu código original)
                        System.out.println(c);

                        // Insertamos en Base de Datos
                        pstmt.setString(1, c.getNif());
                        pstmt.setString(2, c.getAdjudicatario());
                        pstmt.setString(3, c.getObjetoGenerico());
                        pstmt.setString(4, c.getObjeto());
                        pstmt.setString(5, c.getFechaAdjudicacion());
                        String importeConPunto = c.getImporte().replace(',', '.').replaceAll("[^0-9.]", ""); //Formateamos para evitar errores de formato
                        pstmt.setDouble(6, Double.parseDouble(importeConPunto));
                        pstmt.setString(7, c.getProveedoresConsultados());

                        pstmt.executeUpdate();
                    }

                    System.out.println("--- DATOS GUARDADOS EN BBDD CORRECTAMENTE ---");
                    conec.close(); // Cerramos la conexión al terminar

                } else {
                    System.err.println("ERROR: No se encuentra el archivo 'contratos.xml'.");
                }

            }

            //En esta parte usaremos DOM solo y unicamente para la salida del fichero
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.newDocument();

            // 2. Crear el elemento raíz <Contratos>
            Element rootElement = doc.createElement("Contratos");
            doc.appendChild(rootElement);

            // Recorremos la lista
            
            for (Contrato c : manejador.getListaContratos()) {

                // Crear nodo Contrato
                Element contrato = doc.createElement("Contrato");
                rootElement.appendChild(contrato);

                // Añadimos los elementos que queremos en el nuevo XML.
                Element nif = doc.createElement("NIF");
                nif.appendChild(doc.createTextNode(c.getNif()));
                contrato.appendChild(nif);

                Element adj = doc.createElement("Adjudicatario");
                adj.appendChild(doc.createTextNode(c.getAdjudicatario()));
                contrato.appendChild(adj);

                Element objG = doc.createElement("Objeto_Generico");
                objG.appendChild(doc.createTextNode(c.getObjetoGenerico()));
                contrato.appendChild(objG);

                Element obj = doc.createElement("Objeto");
                obj.appendChild(doc.createTextNode(c.getObjeto()));
                contrato.appendChild(obj);

                Element fecha = doc.createElement("Fecha_adjudicacion");
                fecha.appendChild(doc.createTextNode(c.getFechaAdjudicacion()));
                contrato.appendChild(fecha);

                Element importe = doc.createElement("Importe");
                importe.appendChild(doc.createTextNode(c.getImporte()));
                contrato.appendChild(importe);

                Element prov = doc.createElement("Proveedores_Consultados");
                prov.appendChild(doc.createTextNode(c.getProveedoresConsultados()));
                contrato.appendChild(prov);

                //Como queremos eliminar TIPO DE CONTRATO, no incluiremos el elemento
            }

            // 4. Guardamos el archivo
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();

            transformer.setOutputProperty(OutputKeys.INDENT, "yes");

            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("contratos_modificado.xml")); // Nombre del archivo nuevo

            transformer.transform(source, result);

            System.out.println("¡Archivo XML guardado con éxito!");

        } catch (Exception e) {
            System.err.println("Ha ocurrido un error durante el parseo del XML:");
            e.printStackTrace(); // Imprime la traza de error completa
        }
    }

}
