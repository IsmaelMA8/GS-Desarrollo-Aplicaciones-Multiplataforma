package com.mycompany.teaccesodatos;

public class Contrato {

    private String nif;
    private String adjudicatario;
    private String objetoGenerico;
    private String objeto;
    private String fechaAdjudicacion;
    private String importe;
    private String proveedoresConsultados;
    private String tipoContrato;
    
public Contrato() {
    
    
}

    public String getNif() {
        return nif;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public String getAdjudicatario() {
        return adjudicatario;
    }

    public void setAdjudicatario(String adjudicatario) {
        this.adjudicatario = adjudicatario;
    }

    public String getObjetoGenerico() {
        return objetoGenerico;
    }

    public void setObjetoGenerico(String objetoGenerico) {
        this.objetoGenerico = objetoGenerico;
    }

    public String getObjeto() {
        return objeto;
    }

    public void setObjeto(String objeto) {
        this.objeto = objeto;
    }

    public String getFechaAdjudicacion() {
        return fechaAdjudicacion;
    }

    public void setFechaAdjudicacion(String fechaAdjudicacion) {
        this.fechaAdjudicacion = fechaAdjudicacion;
    }

    public String getImporte() {
        return importe;
    }

    public void setImporte(String importe) {
        this.importe = importe;
    }

    public String getProveedoresConsultados() {
        return proveedoresConsultados;
    }

    public void setProveedoresConsultados(String proveedoresConsultados) {
        this.proveedoresConsultados = proveedoresConsultados;
    }

    public String getTipoContrato() {
        return tipoContrato;
    }

    public void setTipoContrato(String tipoContrato) {
        this.tipoContrato = tipoContrato;
    }

    @Override
    public String toString() {
       return "Contrato{" + "NIF: " + nif + ", Adjudicatario: " + adjudicatario + ", Objeto Generico: " + objetoGenerico + ", Objeto: " + objeto + ", Fecha de Adjudicacion: " + fechaAdjudicacion + ", Importe:" + importe + ", ProveedoresConsultados: " + proveedoresConsultados + ", Tipo deontrato: " + tipoContrato + '}';
    }
    
    

}


