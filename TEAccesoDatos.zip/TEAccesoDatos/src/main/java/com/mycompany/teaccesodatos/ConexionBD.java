package com.mycompany.teaccesodatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private static final String URL = "jdbc:mysql://localhost:3306/contratos?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "";

    public ConexionBD() {

    }
    
    public Connection conectar() {
        Connection conec = null;
        try {
            conec = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("--- Conexión establecida con la Base de Datos ---");
        } catch (SQLException e) {
            System.err.println("Error al conectar: " + e.getMessage());
        }
        return conec;
    }
    
    
    
    
    
}
