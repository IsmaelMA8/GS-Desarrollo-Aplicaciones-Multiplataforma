package com.mycompany.teaccesodatos;

import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ManejadorContratos extends DefaultHandler {

    //Iniciamos los "Checkpoints" por donde debe pasar el manejador, indicado lo que va encontrando en mi XML
    private boolean esContratro = false;
    private boolean esNif = false;
    private boolean esAdjudicatario = false;
    private boolean esObjetoGenerico = false;
    private boolean esObjeto = false;
    private boolean esFechaAdjudicacion = false;
    private boolean esImporte = false;
    private boolean esProveedoresConsultados = false;
    private boolean esTipoContrato = false;

    //Creamos las variables que nos ayudaran a empezar a memorizar estos datos que ha ido leyendo el manejador.
    private ArrayList<Contrato> listaContratos = new ArrayList<>();
    private Contrato contratoActual;

    public ArrayList<Contrato> getListaContratos() { //Este get en PUBLIC ayudará a la MAIN a obtener los contratos guardados.
        return listaContratos;
    }

    public void startElement(String uri, String localName, String qName, Attributes attributes) {
        
        // Aquí detecto cuando empieza un <contrato>
        
        if (qName.equalsIgnoreCase("contrato")) {
            contratoActual = new Contrato();

        }

        if (qName.equalsIgnoreCase("nif")) {
            System.out.println("NIF ENCONTRADO!");
            esNif = true;
        } else if (qName.equalsIgnoreCase("adjudicatario")) {
            System.out.println("ADJUDICATARIO ENCONTRADO!");
            esAdjudicatario = true;
        } else if (qName.equalsIgnoreCase("objetoGenerico")) {
            System.out.println("OBJETO GENERICO ENCONTRADO!");
            esObjetoGenerico = true;
        } else if (qName.equalsIgnoreCase("objeto")) {
            System.out.println("OBJETO ENCONTRADO!");
            esObjeto = true;
        } else if (qName.equalsIgnoreCase("fechaAdjudicacion")) {
            System.out.println("FECHA DE ADJUDICACION ENCONTRADO!");
            esFechaAdjudicacion = true;
        } else if (qName.equalsIgnoreCase("importe")) {
            System.out.println("IMPORTE ENCONTRADO!");
            esImporte = true;
        } else if (qName.equalsIgnoreCase("proveedoresConsultados")) {
            System.out.println("PROVEEDORES CONSULTADOS ENCONTRADO!");
            esProveedoresConsultados = true;
        } else if (qName.equalsIgnoreCase("tipoContrato")) {
            System.out.println("TIPO DE CONTRATO ENCONTRADO!");
            esTipoContrato = true;
        }

    }

    //En primer lugar teniamos que cada bandera imprimiera por pantalla lo que leia el SAX. Ahora modificamos para que guarde los datos en la Array.
    
    public void characters(char[] ch, int start, int length) throws SAXException {
        String texto = new String(ch, start, length).trim();

        if (texto.isEmpty()) {
            return;
        }

        if (esNif) {
            contratoActual.setNif(texto);
        } else if (esAdjudicatario) {
            contratoActual.setAdjudicatario(texto);
        } else if (esObjetoGenerico) {
            contratoActual.setObjetoGenerico(texto);
        } else if (esObjeto) {
            contratoActual.setObjeto(texto);
        } else if (esFechaAdjudicacion) {
            contratoActual.setFechaAdjudicacion(texto);
        } else if (esImporte) {
            contratoActual.setImporte(texto);
        } else if (esProveedoresConsultados) {
            contratoActual.setProveedoresConsultados(texto);
        } else if (esTipoContrato) {
            contratoActual.setTipoContrato(texto);
        }

    }

    public void endElement(String uri, String localName, String qName) throws SAXException {

        if (qName.equalsIgnoreCase("contrato")) {
            listaContratos.add(contratoActual); // Guardamos los contratos en la lista
        }

        if (qName.equalsIgnoreCase("nif")) {
            esNif = false;
        } else if (qName.equalsIgnoreCase("adjudicatario")) {
            esAdjudicatario = false;
        } else if (qName.equalsIgnoreCase("objetoGenerico")) {
            esObjetoGenerico = false;
        } else if (qName.equalsIgnoreCase("objeto")) {
            esObjeto = false;
        } else if (qName.equalsIgnoreCase("fechaAdjudicacion")) {
            esFechaAdjudicacion = false;
        } else if (qName.equalsIgnoreCase("importe")) {
            esImporte = false;
        } else if (qName.equalsIgnoreCase("proveedoresConsultados")) {
            esProveedoresConsultados = false;
        } else if (qName.equalsIgnoreCase("tipoContrato")) {
            esTipoContrato = false;
        }
    }
}
